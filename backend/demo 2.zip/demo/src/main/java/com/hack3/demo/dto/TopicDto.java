package com.hack3.demo.dto;

public class TopicDto {

    private String topic;

    private String msg;

    public TopicDto() {
    }

    public TopicDto(String topic, String msg) {
        this.topic = topic;
        this.msg = msg;
    }


    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
