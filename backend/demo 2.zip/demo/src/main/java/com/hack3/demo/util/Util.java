package com.hack3.demo.util;

public class Util {

    public static Boolean isInit = false;
}
